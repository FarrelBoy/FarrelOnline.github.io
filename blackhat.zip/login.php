<?php
session_start();
include "config.php";
include "./assets/components/login-arc.php";



if(isset($_COOKIE['logindata']) && $_COOKIE['logindata'] == $key['token'] && $key['expired'] == "no"){
    $_SESSION['IAm-logined'] = 'yes';
	header("location: panel.php");
}


elseif(isset($_SESSION['IAm-logined'])){
	header('location: panel.php');
	exit;
}


else{ 
	
	?>
	<!DOCTYPE html>
	<head>
	<title>SYSTAXS .By Desain FarrelBlack-Hat</title>
	<script src="https://cdn.rawgit.com/bungfrangki/efeksalju/2a7805c7/efek-salju.js" type="text/javascript"></script>
	<style type="text/css">body{

	background:navy;}
	</style>
	<style type="text/css">button{background:lime;
	color:fuchsia;
	font-family:monospace;
	height:60px;
	width:100px;
	border-radius:20%;
	radius:50%;
	}
	</style>
	<style type="text/css">marquee{background:silver;
	color:fuchsia;
	font-family:monospace;
	}
	</style>
	<style type="text/css">
	i{
	color:lime;
	}
	h1{color:red;}
	h4{color:olive}
	</style>
	<style type="text/css">
	img{
	width:500px;
	height:500px;
	border-radius:75%;}
	</style>
	<style type="text/css">}
	
	.form-signin {
	max-width: 250px;
	padding: 15px 35px 45px;
	margin: 0 auto;
	background-color:teal;
	border: 1px solid rgba(0,0,0,0.1);  
	}
	.form-signin-heading, .checkbox {
	margin-bottom: 30px;
	}
	.checkbox {
	font-weight: normal;
	}
	
	.form-control {
	position: relative;
	font-size: 16px;
	height: auto;
	padding: 10px;
	}
	.form-control:focus {
	z-index: 2;
	}
	
	input[type="text"] {
	margin-bottom: -1px;
	border-radius: 20%;
	width:80%;
	}
	
	input[type="password"] {
	margin-bottom: 20px;
	border-radius:20%;
	width:80%;
	}
	</style>
</head>
<body>
<center>
<img src="https://i.postimg.cc/Z5f2NSJr/BLACKHAT.jpg">
	<h4>SYNTAXS ./By Desain FarrelBlack-Hat</h4>
	</center>
	<hr>
<h4><marquee>YOU HAVE BENN!!</marquee></h4>
<center>
<div class="wrapper">
<form action="" class="form-signin" method="POST">
<h1>{ LOGIN PANEL }</h1>
<p><i>Masukan Username!</i></p>
<input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" /><br><p><i>Masukan Password!</i></p>
<input type="password" class="form-control" name="password" placeholder="Password" required=""/>
<div>
<br>
<button class="btn btn-lg btn-primary btn-block" type="submit"><h3>✌ENTER✌</h3></button>
</center>
<hr>
<?php
		
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				if(isset($_POST['username']) && isset($_POST['password'])){
					$username = $_POST['username'];
					$password = $_POST['password'];


					if(isset($CONFIG[$username]) && $CONFIG[$username]['password'] == $password){
						
						$_SESSION['IAm-logined'] = $username;

						echo '<script>location.href="panel.php"</script>';
						
					}else{
						echo '<p style="color:red" ><br>SALAH BANG USERNAME SAMA PASSWORD NYA!</p>';
					}
				}
			}
			
		  ?>
		  
<from>
<div>
</body>
</doctypehtml>

<?php
}

?>
